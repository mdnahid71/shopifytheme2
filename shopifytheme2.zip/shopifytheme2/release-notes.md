Dawn 15.3.0 adds pagination to the quick order list, updates settings labels, and introduces a few bug fixes.
### Changed
- Quick order list paginates product variants, improving buyer experience for products containing many variants.
- Theme setting labels were updated across all surfaces to make them less crowded and easier to scan.
### Fixes and improvements
- Fix issue where quick order list displayed the remove all button on small windows, even if no variants were in the cart.
